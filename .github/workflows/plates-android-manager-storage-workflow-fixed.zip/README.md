# Plates Management V9 — Robust Persistent Storage

- IndexedDB V9 is the source of truth.
- Existing V8/V7 database is migrated automatically when possible.
- A new base file is written to a new generation and becomes active only after all rows finish saving.
- The active generation is never cleared during import.
- Incremental additions write only changed plate records.
- Duplicate observations remain inside each plate record.
- Old generations are retained until the new one is fully committed (a safety net against interrupted imports), then swept automatically in the background — see below.
- A single IndexedDB connection is reused to reduce mobile overhead.
- Persistent storage is requested when the browser supports it.
- Every successful save is also mirrored into `localStorage` as an independent backup. If IndexedDB ever comes back empty on load (e.g. after storage eviction), the app automatically restores from this mirror and re-seeds IndexedDB from it.
- If the app detects it's running inside an in-app browser (WhatsApp/Facebook/Instagram/etc.) or that the browser did not grant persistent storage, it shows a dismissible warning banner, since those environments can silently drop site storage — no code on the page can override that; opening the real link in Safari/Chrome (or installing via "Add to Home Screen") is the fix.
- Loading reads only the active generation directly via an IndexedDB key-range query instead of scanning the whole record store, so startup stays fast even if old generations have piled up.
- Old (non-active) generations are swept away automatically in the background a couple of seconds after each successful full save/restore — never the active generation, and never blocking the UI — to stop the record store from growing without bound over time.
- Service-worker cache is V9.

Keep a JSON backup for critical data. Browser storage is local to the exact Vercel origin.
