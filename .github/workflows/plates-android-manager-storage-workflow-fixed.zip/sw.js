const CACHE = "plates-app-v9-share-target-1";
const CORE = ["/", "/index.html", "/manifest.webmanifest", "/icon-192.png", "/icon-512.png"];
const SHARE_DB = "plates-share-inbox-v1";
const SHARE_STORE = "pending";

function openShareDB() {
  return new Promise((resolve, reject) => {
    const req = indexedDB.open(SHARE_DB, 1);
    req.onupgradeneeded = () => {
      const db = req.result;
      if (!db.objectStoreNames.contains(SHARE_STORE)) db.createObjectStore(SHARE_STORE, { keyPath: "id", autoIncrement: true });
    };
    req.onsuccess = () => resolve(req.result);
    req.onerror = () => reject(req.error || new Error("share db open failed"));
  });
}

async function saveSharedFile(file, title = "", text = "", url = "") {
  const db = await openShareDB();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(SHARE_STORE, "readwrite");
    tx.objectStore(SHARE_STORE).add({
      file,
      name: file?.name || "shared-file.xlsx",
      type: file?.type || "application/octet-stream",
      title, text, url,
      createdAt: Date.now()
    });
    tx.oncomplete = () => { db.close(); resolve(true); };
    tx.onerror = () => { db.close(); reject(tx.error || new Error("share save failed")); };
    tx.onabort = () => { db.close(); reject(tx.error || new Error("share save aborted")); };
  });
}

self.addEventListener("install", event => {
  event.waitUntil(
    caches.open(CACHE)
      .then(cache => cache.addAll(CORE))
      .then(() => self.skipWaiting())
  );
});

self.addEventListener("activate", event => {
  event.waitUntil(
    caches.keys()
      .then(keys => Promise.all(keys.filter(k => k !== CACHE).map(k => caches.delete(k))))
      .then(() => self.clients.claim())
  );
});

self.addEventListener("fetch", event => {
  // Android/Chrome Web Share Target sends the shared file as a POST navigation.
  // A static Vercel site cannot process that POST server-side, so the service worker
  // receives it, stores the file in a tiny separate IndexedDB inbox, then redirects
  // the installed app to its normal GET route.
  if (event.request.method === "POST" && new URL(event.request.url).pathname === "/") {
    event.respondWith((async () => {
      try {
        const form = await event.request.formData();
        let file = form.get("file");
        if (!(file instanceof File)) {
          const candidates = [];
          for (const [key, value] of form.entries()) if (value instanceof File) candidates.push(value);
          file = candidates[0] || null;
        }
        if (file) {
          await saveSharedFile(file, String(form.get("title") || ""), String(form.get("text") || ""), String(form.get("url") || ""));
        }
      } catch (e) {
        // Still open the app; it can show its normal file picker if sharing failed.
      }
      return Response.redirect(new URL("/?shared=1", self.location.origin), 303);
    })());
    return;
  }

  if (event.request.method !== "GET") return;

  if (event.request.mode === "navigate") {
    event.respondWith(
      fetch(event.request)
        .then(response => {
          if (response.ok) {
            const copy = response.clone();
            caches.open(CACHE).then(cache => cache.put("/index.html", copy)).catch(() => {});
          }
          return response;
        })
        .catch(() => caches.match("/index.html"))
    );
    return;
  }

  event.respondWith(
    caches.match(event.request).then(cached => {
      if (cached) return cached;
      return fetch(event.request).then(response => {
        if (response.ok && new URL(event.request.url).origin === self.location.origin) {
          const copy = response.clone();
          caches.open(CACHE).then(cache => cache.put(event.request, copy)).catch(() => {});
        }
        return response;
      });
    })
  );
});
